import react, { Fragment, useState } from 'react';
import HospitalService from '../services/HospitalService';
import {useNavigate} from 'react-router-dom';


const LoginComponent = () =>{

    const [user,setUser] = useState({username:'',password:'',roleid:''});
    const [login,setLogin] = useState({uname:'',pass:'',roleid:''})
    const [message, setMessage] = useState('');
    const [loginmsg,setLoginMsg] = useState('');
    const [records,setRecords] = useState([]);
    const [token,setToken] = useState('');
    const serv = new HospitalService();
      // lets define a navigate object
      const navigate = useNavigate();
     
    const loginUser = () =>{
        const data = {
            username:login.uname,
            password:login.pass,
            roleid:parseInt(login.roleid)
        }
        serv.authData(data).then(
            (response)=>{setLoginMsg(`${response.data.message}`)
           setToken(response.data.token);
           localStorage.setItem("mytoken",response.data.token);
         //  history.push("/craeteuser")
         console.log(`res============= ${JSON.stringify(response)}`);
         if(response.data.uname === "Maria"){
            navigate("/calculatebill");
         }else if(response.data.role === 5){
            navigate("/doctorobservation");
         }         
         else{
            navigate("/createuser"); 
         }
           //navigate("/createuser");
        }
        ).catch((error)=>{
            setLoginMsg('Error Occured')
        });
       
    }
    const handleInputChange = (evt) =>{
        setLogin({...login,[evt.target.name]:evt.target.value});
    }
    const clear = () =>{
        setUser({username:'',password:''});
    }
    return(
        <Fragment >
            <div class="jumbotron-fluid mt-5" >
  <h1 class="display-4 text-center"></h1>
  <h2 class="display-4 text-center">Health Care System</h2>
  
</div>
            <div className='container mt-5'>

       {/* Login */}
       {/* <h1 className='text-center'>Secured Rest Api Call</h1> */}
      
        <h1 >Login</h1>
       <div className='form-group'>
           <label htmlFor="">Username</label>
           <input type="text" name="uname" id="" value={login.uname} onChange={handleInputChange} className='form-control'/>
       </div>   
       <br></br> 
       <div className='form-group'>
            <label htmlFor="">Password</label>
           <input type="password" name="pass" id="" value={login.pass} onChange={handleInputChange} className='form-control'/>
       </div>
       <br></br> 
       <div className='form-group'>
            <label htmlFor="">Select Role</label>
            <select className='form-control' name='roleid' onChange={handleInputChange}>
                <option>--Select--</option>
                <option value="1">Reception(Admin)</option>
                <option value="5">Doctor</option>
                <option value="4">Accountant</option>
            </select>
       </div>
       <br></br> 
       <div className='container text-center mt-3 '>
       <div className='container'>
        <strong>{loginmsg}</strong>
        </div>
           <button type='button' className='btn btn-dark' onClick={loginUser}>Login</button>| 
           <button type='button' className='btn btn-dark' onClick={clear}>Clear</button>
       </div>
    </div>
 
        </Fragment>
    );
}
export default LoginComponent;