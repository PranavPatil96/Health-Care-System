import react, { Fragment, useState } from "react";

import { Link } from "react-router-dom";

import HospitalService from '../services/HospitalService';

const DoctorObservationComponent = () => {
  const [observation, setObservation] = useState({ userid: "", prescription: "" });

  const serv = new HospitalService();

  let i = 6;

  const [message, setMessage] = useState("");

  const handleInputChange = (evt) => {
    console.log("is it called" + evt.target.value);

    setObservation({ ...observation, [evt.target.name]: evt.target.value });
  };

  const clear = () => {
    setObservation({ userid: "", prescription: "" });
  };

  let n = Math.random();

  n = n * 100;

  const createWard = () => {
    console.log(localStorage.getItem("mytoken"));

    let mytoken = localStorage.getItem("mytoken");

    const data = {
      id: Math.floor(n) + 1,

      userid: observation.userid,

      prescription: observation.prescription,
    };

    serv
      .postObservationData(data, mytoken)
      .then((response) => {
        setMessage(`${response.data.message}`);
      })
      .catch((error) => {
        setMessage("Error Occured");
      });
  };
  return (
    <Fragment>
      <h1>Observe patient</h1>

      <div className="form-group">
        <label htmlFor="">Patient</label>

        <input
          type="text"
          name="userid"
          id=""
          value={observation.userid}
          onChange={handleInputChange}
          className="form-control"
        />
      </div>

      <div className="form-group">
        <label htmlFor="">Prescription</label>

        <input
          type="text"
          name="prescription"
          id=""
          value={observation.prescription}
          onChange={handleInputChange}
          className="form-control"
        />
      </div>

      <div className="container text-center mt-3 ">
        <div className="container"></div>
        <button type="button" className="btn btn-dark" onClick={createWard}>
          Add Observation
        </button>
        |
        <button type="button" className="btn btn-dark" onClick={clear}>
          Clear
        </button>
      </div>
    </Fragment>
  );
};

export default DoctorObservationComponent;
