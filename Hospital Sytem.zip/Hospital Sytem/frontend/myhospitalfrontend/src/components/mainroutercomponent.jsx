import React from "react";
// Import Router Object Model to define Route Table
import { Router, Routes, Route } from "react-router-dom";
import AdmitPatientComponent from "./admitpatientcomponent";
import CreateBillComponent from "./createbillcomponent";
import CreateDoctorComponent from "./createdoctorcomponent";
import CreateRoomComponent from "./createroomcomponent";
import CreateUserComponent from "./createusercomponent";
import CreateWardComponent from "./creatwardcomponent";
import DoctorObservationComponent from "./doctorobservationcomponent";
import LayoutComponent from "./layoutcomponent";
import ListRecordComponent from "./listrecordcomponent";
import ListWardWiseRecordComponent from "./listwardwiserecordcomponent";
import LoginComponent from "./logincomponent";
const MainRouterComponent = () => {
  return (
    <div className="container">
      <Routes>
        <Route path="/" element={<LoginComponent />} />
        <Route path="/calculatebill" element={<CreateBillComponent />}/>
        <Route path="/doctorobservation" element={<DoctorObservationComponent />}/>
        <Route path="/" element={<LayoutComponent />}>
          <Route path="/createuser" element={<CreateUserComponent />} />
          <Route path="/createward" element={<CreateWardComponent />} />
          <Route path="/createroom" element={<CreateRoomComponent />} />
          <Route path="/createdoctor" element={<CreateDoctorComponent />} />
          <Route path="/admitpatient" element={<AdmitPatientComponent />} />
          
          <Route path="/showwardrecords" element={<ListWardWiseRecordComponent />} />
          {/* <Route path="/addpatient" element={<ListDepartmentsComponent />} /> */}

          {/* Route with the Route Parameter */}
          {/* <Route path="*" element={<NotFoundComponent />} /> */}
        </Route>
      </Routes>
    </div>
  );
};

export default MainRouterComponent;
