import react, { Fragment, useState } from 'react';
import { Link } from 'react-router-dom';

import HospitalService from '../services/HospitalService';
const CreateBillComponent = () => {
    const [user,setBill] = useState({userid:0,roombill:0,doctorvisitbill:0,medicinebill:0,nursebill:0,cleaningcharges:0,pathologycharges:0,radiologicharges:0,totalamount:0})
    const serv = new HospitalService();
    let i = 6;
    const [message, setMessage] = useState('');
    const handleInputChange = (evt) =>{
        console.log("is it called"+evt.target.value);
        setBill({...user,[evt.target.name]:evt.target.value});
    }
    const clear = () =>{
        setBill({userid:0,roombill:0,doctorvisitbill:0,medicinebill:0,nursebill:0,cleaningcharges:0,pathologycharges:0,radiologicharges:0,totalamount:0});
    }

    let n = Math.random();
    n = n * 100;
    let res;
    const createBill = () =>{
       console.log(localStorage.getItem("mytoken"));
       let mytoken = localStorage.getItem("mytoken");
        const data = {
            id:(Math.floor(n)+1),
            userid:user.userid,
            roombill:user.roombill,
            doctorvisitbill:user.doctorvisitbill,
            medicinebill:user.medicinebill,
            nursebill:user.nursebill,
            cleaningcharges:user.cleaningcharges,
            pathologycharges:user.pathologycharges,
            radiologicharges:user.radiologicharges,
            totalamount:res
        }
        serv.postBillData(data,mytoken).then(
           
            (response)=>{setMessage(`${response.data.message}`)
        alert("Bill created successfully");
        }
        ).catch((error)=>{
            setMessage('Error Occured')
        });
    }

    const calculate = (user) => {
        var userid = parseInt(document.getElementById("userid").value);
        var roombill = parseInt(document.getElementById("roombill").value);
        var doctorvisitbill = parseInt(document.getElementById("doctorvisitbill").value);
        var medicinebill = parseInt(document.getElementById("medicinebill").value);
        var nursebill = parseInt(document.getElementById("nursebill").value);
        var cleaningcharges = parseInt(document.getElementById("cleaningcharges").value);
        var pathologycharges = parseInt(document.getElementById("pathologycharges").value);
        var radiologicharges = parseInt(document.getElementById("radiologicharges").value);

        res = doctorvisitbill + roombill + medicinebill + nursebill + cleaningcharges + pathologycharges + radiologicharges;
        console.log("res---------------------------", res);
    }
    return(
        <Fragment>
            <h1>Create Bill</h1>
            <div className='form-group'>
           <label htmlFor="">UserID</label>
           <input type="text" name='userid'  id="userid" value={user.userid} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">Roombill</label>
           <input type="text" name='roombill'  id="roombill" value={user.roombill} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">Doctorvisitbill</label>
           <input type="text" name='doctorvisitbill'  id="doctorvisitbill" value={user.doctorvisitbill} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">Medicinebill</label>
           <input type="text" name='medicinebill'  id="medicinebill" value={user.medicinebill} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">Nursebill</label>
           <input type="text" name='nursebill'  id="nursebill" value={user.nursebill} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">Cleaningcharges</label>
           <input type="text" name='cleaningcharges'  id="cleaningcharges" value={user.cleaningcharges} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">Pathologycharges</label>
           <input type="text" name='pathologycharges'  id="pathologycharges" value={user.pathologycharges} onChange={handleInputChange} className='form-control'/>
       </div>
       <div className='form-group'>
           <label htmlFor="">Radiologicharges</label>
           <input type="text" name='radiologicharges'  id="radiologicharges" value={user.radiologicharges} onChange={handleInputChange} className='form-control'/>
       </div>
       {/* <div className='form-group'>
           <label htmlFor="">TotalAmount</label>
           <input type="text" name='totalamount'  id="" value={user.totalamount} onChange={handleInputChange} className='form-control'/>
       </div> */}
       
       <div className='container text-center mt-3 '>
       <div className='container'>
        </div>
           <button type='button' className='btn btn-dark' onClick={createBill}>Add Bill</button>|
           <button type='button' className='btn btn-dark' onClick={calculate}>Total</button>|
           <button type='button' className='btn btn-dark' onClick={clear}>Clear</button>
       </div>
        </Fragment>
    )
}
export default CreateBillComponent;