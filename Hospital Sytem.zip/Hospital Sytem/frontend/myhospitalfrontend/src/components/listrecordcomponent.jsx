import React, { useState, useEffect } from "react";
import {Link} from 'react-router-dom';
import HospitalService from "../services/HospitalService";

const ListRecordComponent = () => {
  const [doctorpatient, setDoctorwisepatient] = useState([]);
  const [currentpatient, setCurentpatient] = useState([]);
  const [wardwiseroom,setWardwiseRoom] = useState([]);
  const [wardwisepatient,setWardwisePatient] = useState([]);

  
  const [message, setMessage] = useState("");
  const serv = new HospitalService();

  useEffect(()=>{
  
      async function loadData(){
          try {
              let response = await serv.getDoctorwiseData();
              setDoctorwisepatient(response.data.data);
          }catch(ex){
              setMessage(`Error Occurred in Loading data ${ex.message}`);
          }
      }
    
          
     
      async function loadCurrentPatientData(){
        try {
            let response = await serv.getCurrentPatientData();
            setCurentpatient(response.data.data);
        }catch(ex){
            setMessage(`Error Occurred in Loading data ${ex.message}`);
        }
    }
    loadData(); 
    loadCurrentPatientData();
    // async function loadWardswiseRoomData(){
    //     try {
    //         let response = await serv.getWardWiseRoomData();
    //         setWardwiseRoom(response.data.data);
    //     }catch(ex){
    //         setMessage(`Error Occurred in Loading data ${ex.message}`);
    //     }
    // }
    // loadWardswiseRoomData(); 
    // async function loadWardswisePatient(){
    //     try {
    //         let response = await serv.getWardWisePatientData();
    //         setWardwisePatient(response.data.data);
    //     }catch(ex){
    //         setMessage(`Error Occurred in Loading data ${ex.message}`);
    //     }
    // }
          
    //  loadWardswisePatient();
      
  },[]);

  

  if (doctorpatient.length === 0 && currentpatient.length === 0 && wardwiseroom.length === 0 && wardwisepatient.length === 0) {
        <div className="container">
            <h2>No records to Show</h2>
        </div>
  } else {
    return (
      <div className="container">
        <h1>Doctorwise Patient</h1>
        <table className="table table-striped table-dark">
            <thead>
                <tr>
                    {
                      Object.keys(doctorpatient[0]).map((header,index)=>(
                          <th key={index}>{header}</th>
                      ))
                    }
                </tr>
            </thead>
            <tbody>
                {
                    doctorpatient.map((dept,idx)=>(
                        <tr key={idx}>
                            {
                                 Object.keys(doctorpatient[0]).map((header,index)=>(
                                    <td key={index}>{dept[header]}</td>
                                ))
                            }
                        </tr>
                    ))
                }
            </tbody>
        </table>

        <h1>Current Patient</h1>
        <table className="table table-striped table-dark">
        <thead>
            <tr>
                {
                  Object.keys(currentpatient[0]).map((header,index)=>(
                      <th key={index}>{header}</th>
                  ))
                }
            </tr>
        </thead>
        <tbody>
            {
                currentpatient.map((dept,idx)=>(
                    <tr key={idx}>
                        {
                             Object.keys(currentpatient[0]).map((header,index)=>(
                                <td key={index}>{dept[header]}</td>
                            ))
                        }
                    </tr>
                ))
            }
        </tbody>
    </table>

   
      </div>

      
    );
  }

  
};

export default ListRecordComponent;
