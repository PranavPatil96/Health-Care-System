import React from 'react';
// Router Object Model
import {Link,Outlet} from 'react-router-dom';

const LayoutComponent=()=>{
  return (
      <div className='container'>
          <table className='table table-striped table-dark'>
              <tbody className=''>
                  <tr>
                      {/* <td>
                          This will map to the index in route table
                          refer mainroutingcomponent.js and Route with index attribute 
                          <Link to="/">List Departments</Link>
                      </td>
                      <td>
                          <Link to="/create">Create Department</Link>
                      </td> */}
                      <td>
                          <Link to="/createuser" >Create user</Link>
                      </td>
                      <td>
                          <Link to="/createward">Add Ward</Link>
                      </td>
                      <td>
                          <Link to="/createroom">Add Room</Link>
                      </td>
                      <td>
                          <Link to="/createdoctor">Add Doctor</Link>
                      </td>
                      <td>
                          <Link to="/admitpatient">Admit Patient</Link>
                      </td>
                      <td>
                          <Link to="/showwardrecords">All Reports</Link>
                      </td>
                  </tr>
              </tbody>
          </table>
          <hr/>
          {/* Components will be Mounted Here */}
          <Outlet/>
      </div>
  );
};

export default LayoutComponent;