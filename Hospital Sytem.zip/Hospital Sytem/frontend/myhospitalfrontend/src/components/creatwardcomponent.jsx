import react, { Fragment, useState } from "react";

import { Link } from "react-router-dom";

import HospitalService from '../services/HospitalService';

const CreateWardComponent = () => {
  const [user, setWard] = useState({ wardname: "", wardinfo: "" });

  const serv = new HospitalService();

  let i = 6;

  const [message, setMessage] = useState("");

  const handleInputChange = (evt) => {
    console.log("is it called" + evt.target.value);

    setWard({ ...user, [evt.target.name]: evt.target.value });
  };

  const clear = () => {
    setWard({ wardname: "", wardinfo: "" });
  };

  let n = Math.random();

  n = n * 100;

  const createWard = () => {
    console.log(localStorage.getItem("mytoken"));

    let mytoken = localStorage.getItem("mytoken");

    const data = {
      id: Math.floor(n) + 1,

      wardname: user.wardname,

      wardinfo: user.wardinfo,
    };

    serv
      .postWardData(data, mytoken)
      .then((response) => {
        setMessage(`${response.data.message}`);
      })
      .catch((error) => {
        setMessage("Error Occured");
      });
  };
  return (
    <Fragment>
      <h1>Create Ward</h1>

      <div className="form-group">
        <label htmlFor="">Wardname</label>

        <input
          type="text"
          name="wardname"
          id=""
          value={user.wardname}
          onChange={handleInputChange}
          className="form-control"
        />
      </div>

      <div className="form-group">
        <label htmlFor="">WardInfo</label>

        <input
          type="text"
          name="wardinfo"
          id=""
          value={user.wardinfo}
          onChange={handleInputChange}
          className="form-control"
        />
      </div>

      <div className="container text-center mt-3 ">
        <div className="container"></div>
        <button type="button" className="btn btn-dark" onClick={createWard}>
          Add Ward
        </button>
        |
        <button type="button" className="btn btn-dark" onClick={clear}>
          Clear
        </button>
      </div>
    </Fragment>
  );
};

export default CreateWardComponent;
