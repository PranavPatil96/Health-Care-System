import React, { useState, useEffect } from "react";
import {Link} from 'react-router-dom';
import HospitalService from "../services/HospitalService";

const ListWardWiseRecordComponent = () => {
  const [doctorpatient, setDoctorwisepatient] = useState([]);
  const [currentpatient, setCurentpatient] = useState([]);
  const [wardwiseroom,setWardwiseRoom] = useState([]);
  const [wardwisepatient,setWardwisePatient] = useState([]);
  const [wardwisenurse,setWardwiseNurse] = useState([]);
  const [searchPatient,setSearchPatient] = useState([]);

  const [wardrResult,wardList] = useState([]);

  const [roomResult,roomList] = useState([]);

  const [result,patientList] = useState([]);

  const [observedpatients, setObservedPatients] = useState([]);
  
  const [message, setMessage] = useState("");

  const [user,setUser] = useState({userid:'',room:'',ward:''})
  const serv = new HospitalService();

  useEffect(()=>{
    async function loadData(){
        try {
            let response = await serv.getDoctorwiseData();
            setDoctorwisepatient(response.data.data);
        }catch(ex){
            setMessage(`Error Occurred in Loading data ${ex.message}`);
        }
    }
  
        
   
    async function loadCurrentPatientData(){
      try {
          let response = await serv.getCurrentPatientData();
          setCurentpatient(response.data.data);
          setSearchPatient(response.data.data);
      }catch(ex){
          setMessage(`Error Occurred in Loading data ${ex.message}`);
      }
  }
  loadData(); 
  loadCurrentPatientData();
    async function loadWardswiseRoomData(){
        try {
            let response = await serv.getWardWiseRoomData();
            setWardwiseRoom(response.data.data);
        }catch(ex){
            setMessage(`Error Occurred in Loading data ${ex.message}`);
        }
    }
    loadWardswiseRoomData(); 
    async function loadWardswisePatient(){
        try {
            let response = await serv.getWardWisePatientData();
            setWardwisePatient(response.data.data);
        }catch(ex){
            setMessage(`Error Occurred in Loading data ${ex.message}`);
        }
    }
          
     loadWardswisePatient();
     async function loadWardswiseNurse(){
        try {
            let response = await serv.getWardWiseNurseData();
            setWardwiseNurse(response.data.data);
        }catch(ex){
            setMessage(`Error Occurred in Loading data ${ex.message}`);
        }
    }
          
    loadWardswiseNurse();

    async function loadPatientData(){
            
        fetch(`http://localhost:7011/api/patients`,{
            method:'GET',
            headers:{
                'Content-Type': 'application/json',
            }
            
        })            
        .then(resp => resp.json())
        .then(resp => patientList(resp.data))
        
    }
    loadPatientData();
    async function loadWardData(){
            
        fetch(`http://localhost:7011/api/wards`,{
            method:'GET',
            headers:{
                'Content-Type': 'application/json',
            }
            
        })            
        .then(resp => resp.json())
        .then(resp => wardList(resp.data))
        
    }
    loadWardData();
    async function loadRoomData(){
        
        fetch(`http://localhost:7011/api/rooms`,{
            method:'GET',
            headers:{
                'Content-Type': 'application/json',
            }
            
        })            
        .then(resp => resp.json())
        .then(resp => roomList(resp.data))
        
    }
    loadRoomData();
    async function loadObservedPatientsData() {

        fetch(`http://localhost:7011/api/observedPatients`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }

        })
            .then(resp => resp.json())
            .then(resp => setObservedPatients(resp.data))

    }
    loadObservedPatientsData();
  },[]);

  const searchHandle = async(evt) => {
    console.log(`Event is = ${user.userid} and ${user.room} and ${user.ward}`);
    let key = user.userid;
    let key2 =user.ward;
    let key3 = user.room;
    console.log(`key====================== ${key}`);
    if(key){
        let result = await fetch(`http://localhost:7011/api/searchpatients/${key}/${key2}/${key3}`);
        result = await result.json();
        console.log(`res === ${JSON.stringify(result)}`);
        if(result.message !== "Patient doesn't exist"){
            setSearchPatient(result.data)
        }else{
            try {
                let response = await serv.getCurrentPatientData();
                //setCurentpatient(response.data.data);
                setSearchPatient(response.data.data);
            }catch(ex){
                setMessage(`Error Occurred in Loading data ${ex.message}`);
            }
        }
    }
    
  }

  const handleInputChange = (evt) =>{
    console.log("is it called"+evt.target.value);
    setUser({...user,[evt.target.name]:evt.target.value});
}

  if (wardwiseroom.length === 0 && wardwisepatient.length === 0) {
        <div className="container">
            <h2>No records to Show</h2>
        </div>
  } else {
    return (
      <div className="container">
    <h1>Doctor Wise Patients</h1>
            <table className='table table-bordered table-striped'>
                 <thead>
                   <tr>
                        <th>Patient First Name</th>
                        <th>Patient Last Name</th>
                        <th>Doctor Name</th>
                        
                        
                     </tr>
                </thead>
                <tbody >
                    {
                       
                       doctorpatient.map((dept,idx)=>(
                         <tr key={idx}>
                                 <td >{dept.firstname}</td>
                                 <td >{dept.lastname}</td>
                                 <td >{dept.doctorname}</td>
                                
                               
                                   
                             </tr>
                         ))
                    }
                </tbody>
            </table>    

      <h1>Current Patient Admitted</h1>
            <table className='table table-striped table-dark'>
                 <thead>
                   <tr>
                        <th>Patient Name</th>
                        <th>Ward name</th>
                        <th>Room no</th>
                        <th>Status</th>
                        
                        
                     </tr>
                </thead>
                <tbody >
                    {
                       
                       currentpatient.map((dept,idx)=>(
                         <tr key={idx}>
                                 <td >{dept.firstname}</td>
                                 <td >{dept.wardname}</td>
                                 <td >{dept.roomno}</td>
                                 <td >{dept.status}</td>
                               
                                   
                             </tr>
                         ))
                    }
                </tbody>
            </table>              
    <h1>Ward Wise Room</h1>
    <table className='table table-striped table-dark'>
                 <thead>
                   <tr>
                        <th>Ward Name</th>
                    <th>Room No</th>
                        
                     </tr>
                </thead>
                <tbody >
                    {
                       
                        wardwiseroom.map((dept,idx)=>(
                         <tr key={idx}>
                                 <td >{dept.wardname}</td>
                                 <td >{dept.roomno}</td>
                                
                               
                                   
                             </tr>
                         ))
                    }
                </tbody>
            </table>
                    <h1>Ward Wise Patients</h1>
            <table className='table table-striped table-dark'>
                 <thead>
                   <tr>
                        <th>Patient Name</th>
                    <th>Ward Name</th>
                        
                        
                     </tr>
                </thead>
                <tbody >
                    {
                       
                        wardwisepatient.map((dept,idx)=>(
                         <tr key={idx}>
                                 <td >{dept.firstname + ' '+ dept.lastname}</td>
                                 <td >{dept.wardname}</td>
                                
                               
                                   
                             </tr>
                         ))
                    }
                </tbody>
            </table>

            <h1>Ward Wise Nurse</h1>
            <table className='table table-striped table-dark'>
                 <thead>
                   <tr>
                        <th>Ward Name</th>
                        <th>Nurse Name</th>
                   </tr>
                </thead>
                <tbody >
                    {
                       
                        wardwisenurse.map((dept,idx)=>(
                         <tr key={idx}>
                                 <td >{dept.wardname}</td>
                                 <td >{dept.nursename}</td>                             
                                                                  
                             </tr>
                         ))
                    }
                </tbody>
            </table>

            {/* trying...... */}
            <h1>Search Patient Admitted</h1>
            <div className="form-group">
                <label htmlFor="">Select Patient</label>
            <select className="form-control" name="userid" onChange={handleInputChange} >
                <option  disabled selected>---Select---</option>
                {
                    result.map((list,index) =>{
                        return(
                            <option key={index} value={list.firstname}>{list.firstname}</option>
                        )
                        
                    })
                   
                }                
            </select>

            <label htmlFor="">Select Ward</label>

            <select className="form-control" name="ward"  onChange={handleInputChange}>
                <option  disabled selected>---Select---</option>
                {                 
                   wardrResult.map((list,index) =>{

                        return(

                            <option key={index} value={list.id}>{list.wardname}</option>

                        )

                       

                    })

                   

                }

               

            </select>

            <label htmlFor="">Select Room</label>

            <select className="form-control" name="room"  onChange={handleInputChange}>

                <option  disabled selected>---Select---</option>

                {

                    roomResult.map((list,index) =>{

                        return(

                            <option key={index} value={list.id}>{list.roomno}</option>

                        )

                       

                    })

                   

                }

               

            </select>
            
            </div>
            <button type='button' className='btn btn-dark' onClick={searchHandle}>Search</button>| 
          
            <table className='table table-bordered table-striped'>
                 <thead>
                   <tr>
                        <th>Patient Name</th>
                        <th>Status</th>
                        <th>Wardname</th>
                        <th>Roomno</th>
                        
                     </tr>
                </thead>
                <tbody >
                    {
                       
                      searchPatient.length >0 ? searchPatient.map((dept,idx)=>(
                         <tr key={idx}>
                                 <td >{dept.firstname}</td>
                                 
                                 <td >{dept.status}</td>
                                 <td >{dept.wardname}</td>

                                 <td >{dept.roomno}</td>
                               
                                   
                             </tr>
                         )):<h1>Patient doesn't exist</h1>
                    }
                </tbody>
            </table> 

{/* List observed patients */}
<h1>Observed Patients</h1>
                <table className='table table-striped table-dark'>
                    <thead>
                        <tr>
                            <th>Firstname</th>
                            <th>Username</th>
                            <th>Prescription</th>
                            <th>Status</th>
                            <th>Disease</th>

                        </tr>
                    </thead>
                    <tbody >
                        {

                            observedpatients.map((dept, idx) => (
                                <tr key={idx}>
                                    <td >{dept.firstname}</td>
                                    <td >{dept.username}</td>
                                    <td >{dept.prescription}</td>
                                    <td >{dept.status}</td>
                                    <td >{dept.disease}</td>

                                </tr>
                            ))
                        }
                    </tbody>
                </table>
  
      </div>

      
    );
  }

  
};

export default ListWardWiseRecordComponent;
