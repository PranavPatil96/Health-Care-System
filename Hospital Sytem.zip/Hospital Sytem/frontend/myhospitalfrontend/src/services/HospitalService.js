import axios from "axios";

class HospitalService {
  constructor() {
    this.url = "http://localhost:7011";
  }
  async authData(data) {
    let response = await axios.post(`${this.url}/api/login`, data, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    return response;
  }
  async postData(data, token) {
    let response = await axios.post(`${this.url}/api/createuser`, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    });
    return response;
  }
  async postWardData(data, token) {
    let response = await axios.post(`${this.url}/api/createward`, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    });
    return response;
  }
  async postRoomData(data, token) {
    let response = await axios.post(`${this.url}/api/createroom`, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    });
    return response;
  }
  async postDoctorData(data, token) {
    let response = await axios.post(`${this.url}/api/createnewdoctor`, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    });
    return response;
  }
  async postAdmitPatientData(data, token) {
    let response = await axios.post(`${this.url}/api/admitpatients`, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    });
    return response;
  }

  async postObservationData(data, token) {
    let response = await axios.post(`${this.url}/api/observationonpatient`, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    });
    return response;
  }
  
  //get Doctowise Patients
  async getDoctorwiseData() {
    let response = await axios.get(`${this.url}/api/getdoctorwisepatient`);

    return response;
  }
 // Current patients admitted in Hospital
  async getCurrentPatientData() {
    let response = await axios.get(`${this.url}/api/allpatients`);

    return response;
  }
 // Ward wise Patients
  async getWardWisePatientData() {
    let response = await axios.get(`${this.url}/api/getwardwisepatient`);

    return response;
  }

  // Ward wise Rooms
  async getWardWiseRoomData() {
    let response = await axios.get(`${this.url}/api/getwardwiseroom`);

    return response;
  }

  // Ward wise Nurses
  async getWardWiseNurseData() {
    let response = await axios.get(`${this.url}/api/getwardwisenurse`);

    return response;
  }

  async postBillData(data, token) {
    let response = await axios.post(`${this.url}/api/bill`, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + token,
      },
    });
    return response;
  }
}
export default HospitalService;
