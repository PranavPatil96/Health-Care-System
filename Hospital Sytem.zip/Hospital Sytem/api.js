import express from 'express';
import cors from 'cors';

const PORT =  process.env.PORT || 7011;

// create an instance
const instance = express();
// Add JSON Middleware in HTTP Pipeline
instance.use(express.json());
// do not parse incoming data other than HTTP Request Message Body
instance.use(express.urlencoded({extended:false}));
// configure CORS
instance.use(cors({
    origin: "*",
    methods: "*",
    allowedHeaders: "*"
})); 

// import dataaccess

import DataAccess from './dataaccess/dataaccess.js'

let ds = new DataAccess();
// lets create REST API
instance.post('/api/login', ds.loginUser);
instance.post('/api/createuser', ds.createNewUser);
instance.post('/api/createward', ds.addWard);
instance.post('/api/createroom', ds.addRoom);
instance.post('/api/admitpatients', ds.admitPatient);
instance.post('/api/observationonpatient', ds.observationOnPatient);
instance.post('/api/recordpatientdetail', ds.recordPatientDetail); 
instance.post('/api/bill', ds.generateBill);
instance.post('/api/createnewdoctor', ds.createNewDoctor);

//reports api
// Following reports are needed
// Doctowise Patients
// Current patients admitted in Hospital
// Ward wise Patients
// Ward wise Rooms
// Ward wise nurses
// Search Patient based on Name / Ward / Room
instance.get('/api/getdoctorwisepatient', ds.getDoctorWisePatient);
instance.get('/api/allpatients', ds.getAllAdmittedPatient);
instance.get('/api/getwardwisepatient', ds.getWardWisePatient);
instance.get('/api/getwardwiseroom', ds.getWardWiseRoom);
instance.get('/api/getwardwisenurse', ds.getWardWiseNurse);
instance.get('/api/searchpatients/:id/:wardid/:roomid', ds.searchPatients);
instance.get('/api/observedPatients', ds.getAllObservedPatients)

//trying....
instance.get('/api/patients', ds.getPatientData);
instance.get('/api/wards', ds.getWardData);
instance.get('/api/rooms', ds.getRoomData);
instance.get('/api/doctors', ds.getDoctorData);
// start listening
instance.listen(PORT, ()=>{
    console.log(`Started on port ${PORT}`);
});